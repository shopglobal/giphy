Week 6 homework assignment:

Giphy API

API Properties and jQuery / Ajax Calls - Basic Assignment User Story

I created an App full of gifs using the giphy api!
Here is the documentation for the Giphy API: https://github.com/Giphy/GiphyAPI
I made an array of actions and made buttons out of them.
When you click on a button, 10 images are retrieved from giphy and displayed on the page.
When you click on the image, the gif plays. When you click again, the gif stops playing.
Yu can add a new action from the form on the right side of the page. The actions will be added to the array of actions and added as a new button
The rating of each gif will also appear on the page.
Heroku: https://shopglobal.github.io/giphy

Copyright

Mark Allen Evans (C) 2017. All Rights Reserved.